// src/services/sync.service.js
const { prisma } = require('../config/database');
const logger = require('../utils/logger');
const axios = require('axios');

/**
 * Sync user data from auth-service to user-service cache
 */
const syncUserFromAuthService = async (userData) => {
    try {
        const userCacheData = {
            id: userData.id,
            email: userData.email,
            username: userData.username,
            firstName: userData.firstName,
            lastName: userData.lastName,
            bio: userData.bio,
            location: userData.location,
            profilePicture: userData.profilePicture,
            coverImage: userData.coverImage,
            instagramHandle: userData.instagramHandle,
            twitterHandle: userData.twitterHandle,
            linkedinHandle: userData.linkedinHandle,
            youtubeHandle: userData.youtubeHandle,
            website: userData.website,
            contentCategories: userData.contentCategories || [],
            primaryNiche: userData.primaryNiche,
            primaryPlatform: userData.primaryPlatform,
            estimatedFollowers: userData.estimatedFollowers,
            companyName: userData.companyName,
            companyType: userData.companyType,
            industry: userData.industry,
            companyWebsite: userData.companyWebsite,
            targetAudience: userData.targetAudience || [],
            campaignTypes: userData.campaignTypes || [],
            crewSkills: userData.crewSkills || [],
            experienceLevel: userData.experienceLevel,
            equipmentOwned: userData.equipmentOwned || [],
            portfolioUrl: userData.portfolioUrl,
            hourlyRate: userData.hourlyRate,
            availability: userData.availability,
            specializations: userData.specializations || [],
            roles: userData.roles,
            status: userData.status,
            isActive: userData.isActive,
            emailVerified: userData.emailVerified,
            createdAt: userData.createdAt,
            updatedAt: userData.updatedAt,
            lastActiveAt: userData.lastActiveAt,
            lastSyncAt: new Date()
        };

        // Upsert user cache
        await prisma.userCache.upsert({
            where: { id: userData.id },
            update: userCacheData,
            create: userCacheData
        });

        // Update search score based on profile completeness
        await updateSearchScore(userData.id);

        logger.info(`User cache synced for user ${userData.id}`);
        return { success: true, userId: userData.id };
    } catch (error) {
        logger.error(`Error syncing user ${userData.id}:`, error);
        throw error;
    }
};

/**
 * Create user cache for a new user
 */
const createUserCache = async (userData) => {
    try {
        await syncUserFromAuthService(userData);

        // Create initial analytics record
        await prisma.userAnalytics.create({
            data: {
                userId: userData.id,
                profileViews: 0,
                searchAppearances: 0,
                popularityScore: 0,
                engagementScore: 0
            }
        });

        logger.info(`User cache and analytics created for new user ${userData.id}`);
        return { success: true, userId: userData.id };
    } catch (error) {
        logger.error(`Error creating user cache for ${userData.id}:`, error);
        throw error;
    }
};

/**
 * Delete user cache and related data
 */
const deleteUserCache = async (userId) => {
    try {
        // Delete in transaction to ensure consistency
        await prisma.$transaction(async (tx) => {
            // Delete analytics
            await tx.userAnalytics.deleteMany({
                where: { userId }
            });

            // Delete favorites (both ways)
            await tx.userFavorite.deleteMany({
                where: {
                    OR: [
                        { userId },
                        { favoriteUserId: userId }
                    ]
                }
            });

            // Delete user cache
            await tx.userCache.delete({
                where: { id: userId }
            });
        });

        logger.info(`User cache and related data deleted for user ${userId}`);
        return { success: true, userId };
    } catch (error) {
        logger.error(`Error deleting user cache for ${userId}:`, error);
        throw error;
    }
};

/**
 * Sync all users from auth-service
 */
const syncAllUsersFromAuthService = async () => {
    try {
        const authServiceUrl = process.env.AUTH_SERVICE_URL || 'http://localhost:4001';

        // Fetch all users from auth-service
        const response = await axios.get(`${authServiceUrl}/internal/users`, {
            headers: {
                'X-Internal-Service': 'user-service'
            }
        });

        const users = response.data.users;
        let syncedCount = 0;
        let errorCount = 0;

        for (const user of users) {
            try {
                await syncUserFromAuthService(user);
                syncedCount++;
            } catch (error) {
                logger.error(`Failed to sync user ${user.id}:`, error);
                errorCount++;
            }
        }

        const result = {
            totalUsers: users.length,
            syncedCount,
            errorCount,
            syncedAt: new Date().toISOString()
        };

        logger.info(`Bulk sync completed: ${syncedCount} users synced, ${errorCount} errors`);
        return result;
    } catch (error) {
        logger.error('Error during bulk sync:', error);
        throw error;
    }
};

/**
 * Sync a single user from auth-service
 */
const syncSingleUserFromAuthService = async (userId) => {
    try {
        const authServiceUrl = process.env.AUTH_SERVICE_URL || 'http://localhost:4001';

        // Fetch user from auth-service
        const response = await axios.get(`${authServiceUrl}/internal/users/${userId}`, {
            headers: {
                'X-Internal-Service': 'user-service'
            }
        });

        const user = response.data.user;
        await syncUserFromAuthService(user);

        return {
            success: true,
            userId,
            syncedAt: new Date().toISOString()
        };
    } catch (error) {
        logger.error(`Error syncing single user ${userId}:`, error);
        throw error;
    }
};

/**
 * Get sync status and health information
 */
const getSyncStatus = async () => {
    try {
        // Get cache statistics
        const cacheStats = await prisma.userCache.groupBy({
            by: ['roles', 'status'],
            _count: {
                id: true
            }
        });

        // Get sync freshness
        const oldestSync = await prisma.userCache.findFirst({
            orderBy: { lastSyncAt: 'asc' },
            select: { lastSyncAt: true, id: true }
        });

        const newestSync = await prisma.userCache.findFirst({
            orderBy: { lastSyncAt: 'desc' },
            select: { lastSyncAt: true, id: true }
        });

        // Get analytics coverage
        const totalUsers = await prisma.userCache.count();
        const usersWithAnalytics = await prisma.userAnalytics.count();

        return {
            cacheStatistics: cacheStats,
            syncFreshness: {
                oldestSync: oldestSync?.lastSyncAt,
                newestSync: newestSync?.lastSyncAt,
                staleCacheUsers: oldestSync ? await prisma.userCache.count({
                    where: {
                        lastSyncAt: {
                            lt: new Date(Date.now() - 24 * 60 * 60 * 1000) // 24 hours ago
                        }
                    }
                }) : 0
            },
            analyticsCoverage: {
                totalUsers,
                usersWithAnalytics,
                coveragePercentage: totalUsers > 0 ? Math.round((usersWithAnalytics / totalUsers) * 100) : 0
            },
            lastChecked: new Date().toISOString()
        };
    } catch (error) {
        logger.error('Error getting sync status:', error);
        throw error;
    }
};

/**
 * Update search score based on profile completeness and activity
 */
const updateSearchScore = async (userId) => {
    try {
        const user = await prisma.userCache.findUnique({
            where: { id: userId }
        });

        const analytics = await prisma.userAnalytics.findUnique({
            where: { userId }
        });

        if (!user) return;

        let score = 0;

        // Profile completeness (40 points max)
        if (user.profilePicture) score += 8;
        if (user.bio && user.bio.length > 20) score += 12;
        if (user.location) score += 5;
        if (user.website) score += 5;

        // roles-specific completeness (30 points max)
        if (user.roles === 'INFLUENCER') {
            if (user.primaryNiche) score += 10;
            if (user.primaryPlatform) score += 8;
            if (user.contentCategories?.length > 0) score += 7;
            if (user.estimatedFollowers) score += 5;
        } else if (user.roles === 'BRAND') {
            if (user.companyName) score += 10;
            if (user.industry) score += 10;
            if (user.companyType) score += 5;
            if (user.targetAudience?.length > 0) score += 5;
        } else if (user.roles === 'CREW') {
            if (user.crewSkills?.length > 0) score += 10;
            if (user.experienceLevel) score += 8;
            if (user.portfolioUrl) score += 7;
            if (user.hourlyRate) score += 5;
        }

        // Activity and engagement (30 points max)
        if (analytics) {
            const viewsScore = Math.min(analytics.profileViews / 10, 10); // Max 10 points
            const searchScore = Math.min(analytics.searchAppearances / 5, 10); // Max 10 points
            const popularityScore = analytics.popularityScore * 10; // Max 10 points

            score += viewsScore + searchScore + popularityScore;
        }

        // Recent activity bonus (max 100 total)
        const daysSinceLastActive = user.lastActiveAt ?
            (Date.now() - new Date(user.lastActiveAt).getTime()) / (1000 * 60 * 60 * 24) : 30;

        if (daysSinceLastActive <= 1) score *= 1.0;
        else if (daysSinceLastActive <= 7) score *= 0.9;
        else if (daysSinceLastActive <= 30) score *= 0.7;
        else score *= 0.5;

        // Normalize to 0-1 scale
        const normalizedScore = Math.min(score / 100, 1);

        await prisma.userCache.update({
            where: { id: userId },
            data: { searchScore: normalizedScore }
        });

    } catch (error) {
        logger.error(`Error updating search score for user ${userId}:`, error);
    }
};

/**
 * Sync users by roles
 */
const syncUsersByroles = async (roles) => {
    try {
        const users = await prisma.user.findMany({
            where: {
                roles: { has: roles }
            },
            select: {
                id: true,
                email: true,
                username: true,
                firstName: true,
                lastName: true,
                bio: true,
                location: true,
                profilePicture: true,
                coverImage: true,
                instagramHandle: true,
                twitterHandle: true,
                linkedinHandle: true,
                youtubeHandle: true,
                website: true,
                contentCategories: true,
                primaryNiche: true,
                primaryPlatform: true,
                estimatedFollowers: true,
                companyName: true,
                companyType: true,
                industry: true,
                companyWebsite: true,
                targetAudience: true,
                campaignTypes: true,
                crewSkills: true,
                experienceLevel: true,
                equipmentOwned: true,
                portfolioUrl: true,
                hourlyRate: true,
                availability: true,
                specializations: true,
                roles: true,
                status: true,
                isActive: true,
                emailVerified: true,
                createdAt: true,
                updatedAt: true,
                lastActiveAt: true,
                lastSyncAt: true
            }
        });

        let syncedCount = 0;
        let errorCount = 0;

        for (const user of users) {
            try {
                await syncUserFromAuthService(user);
                syncedCount++;
            } catch (error) {
                logger.error(`Failed to sync user ${user.id}:`, error);
                errorCount++;
            }
        }

        const result = {
            totalUsers: users.length,
            syncedCount,
            errorCount,
            syncedAt: new Date().toISOString()
        };

        logger.info(`roles-based sync completed for ${roles}: ${syncedCount} users synced, ${errorCount} errors`);
        return result;
    } catch (error) {
        logger.error(`Error during roles-based sync for ${roles}:`, error);
        throw error;
    }
};

module.exports = {
    syncUserFromAuthService,
    createUserCache,
    deleteUserCache,
    syncAllUsersFromAuthService,
    syncSingleUserFromAuthService,
    getSyncStatus,
    updateSearchScore,
    syncUsersByroles
};

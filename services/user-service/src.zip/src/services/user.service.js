// src/services/user.service.js
const { prisma } = require('../config/database');
const { NotFoundError } = require('../middleware/error-handler');
const logger = require('../utils/logger');

/**
 * Get user by ID (read-only from shared database)
 */
const getUserById = async (userId) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId }
        });

        if (!user) {
            return null;
        }

        // Remove sensitive information for user-servic
        delete user.password;
        delete user.passwordResetToken;
        delete user.passwordResetExpires;
        delete user.emailVerificationToken;
        delete user.twoFactorSecret;

        return user;
    } catch (error) {
        logger.error(`Error getting user by ID: ${userId}`, error);
        throw error;
    }
};

/**
 * Get public user profile
 */
const getPublicUserProfile = async (userId) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId }
        });

        if (!user) {
            return null;
        }

        // Return only public fields
        return {
            id: user.id,
            firstName: user.firstName,
            lastName: user.lastName,
            username: user.username,
            profilePicture: user.profilePicture,
            coverImage: user.coverImage,
            bio: user.bio,
            location: user.location,
            roles: user.roles, // <-- return roles array
            instagramHandle: user.instagramHandle,
            twitterHandle: user.twitterHandle,
            linkedinHandle: user.linkedinHandle,
            youtubeHandle: user.youtubeHandle,
            website: user.website,
            createdAt: user.createdAt
        };
    } catch (error) {
        logger.error(`Error getting public user profile: ${userId}`, error);
        throw error;
    }
};

/**
 * Get public influencer profile (multi-roles)
 */
const getPublicInfluencerProfile = async (userId) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId },
        });
        if (!user || !Array.isArray(user.roles) || !user.roles.includes('INFLUENCER')) {
            return null;
        }
        // Return influencer-specific public fields
        return {
            id: user.id,
            firstName: user.firstName,
            lastName: user.lastName,
            username: user.username,
            profilePicture: user.profilePicture,
            coverImage: user.coverImage,
            bio: user.bio,
            location: user.location,
            instagramHandle: user.instagramHandle,
            twitterHandle: user.twitterHandle,
            linkedinHandle: user.linkedinHandle,
            youtubeHandle: user.youtubeHandle,
            website: user.website,
            contentCategories: user.contentCategories,
            primaryNiche: user.primaryNiche,
            primaryPlatform: user.primaryPlatform,
            estimatedFollowers: user.estimatedFollowers,
            createdAt: user.createdAt
        };
    } catch (error) {
        logger.error(`Error getting public influencer profile: ${userId}`, error);
        throw error;
    }
};

/**
 * Get public brand profile (multi-roles)
 */
const getPublicBrandProfile = async (userId) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId },
        });
        if (!user || !Array.isArray(user.roles) || !user.roles.includes('BRAND')) {
            return null;
        }
        // Return brand-specific public fields
        return {
            id: user.id,
            firstName: user.firstName,
            lastName: user.lastName,
            username: user.username,
            profilePicture: user.profilePicture,
            coverImage: user.coverImage,
            bio: user.bio,
            location: user.location,
            companyName: user.companyName,
            companyType: user.companyType,
            industry: user.industry,
            companyWebsite: user.companyWebsite,
            instagramHandle: user.instagramHandle,
            twitterHandle: user.twitterHandle,
            linkedinHandle: user.linkedinHandle,
            youtubeHandle: user.youtubeHandle,
            website: user.website,
            targetAudience: user.targetAudience,
            campaignTypes: user.campaignTypes,
            createdAt: user.createdAt
        };
    } catch (error) {
        logger.error(`Error getting public brand profile: ${userId}`, error);
        throw error;
    }
};

/**
 * Get public crew profile (multi-roles)
 */
const getPublicCrewProfile = async (userId) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: userId },
        });
        if (!user || !Array.isArray(user.roles) || !user.roles.includes('CREW')) {
            return null;
        }
        // Return crew-specific public fields
        return {
            id: user.id,
            firstName: user.firstName,
            lastName: user.lastName,
            username: user.username,
            profilePicture: user.profilePicture,
            coverImage: user.coverImage,
            bio: user.bio,
            location: user.location,
            crewSkills: user.crewSkills,
            experienceLevel: user.experienceLevel,
            equipmentOwned: user.equipmentOwned,
            portfolioUrl: user.portfolioUrl,
            hourlyRate: user.hourlyRate,
            availability: user.availability,
            specializations: user.specializations,
            instagramHandle: user.instagramHandle,
            twitterHandle: user.twitterHandle,
            linkedinHandle: user.linkedinHandle,
            youtubeHandle: user.youtubeHandle,
            website: user.website,
            createdAt: user.createdAt
        };
    } catch (error) {
        logger.error(`Error getting public crew profile: ${userId}`, error);
        throw error;
    }
};

/**
 * Search users with filters (multi-roles)
 */
const searchUsers = async (filters = {}) => {
    try {
        const {
            query,
            roles,
            location,
            limit = 20,
            offset = 0
        } = filters;
        const whereClause = {};
        if (query) {
            whereClause.OR = [
                { firstName: { contains: query, mode: 'insensitive' } },
                { lastName: { contains: query, mode: 'insensitive' } },
                { username: { contains: query, mode: 'insensitive' } },
                { bio: { contains: query, mode: 'insensitive' } }
            ];
        }
        // Filter by roles (multi-roles)
        if (roles) {
            whereClause.roles = { has: roles };
        }
        if (location) {
            whereClause.location = { contains: location, mode: 'insensitive' };
        }
        const users = await prisma.user.findMany({
            where: whereClause,
            select: {
                id: true,
                firstName: true,
                lastName: true,
                username: true,
                profilePicture: true,
                bio: true,
                location: true,
                roles: true,
                createdAt: true
            },
            orderBy: [
                { createdAt: 'desc' }
            ],
            take: limit,
            skip: offset
        });
        const total = await prisma.user.count({ where: whereClause });
        return {
            users,
            pagination: {
                total,
                limit,
                offset,
                hasMore: offset + limit < total
            }
        };
    } catch (error) {
        logger.error('Error searching users:', error);
        throw error;
    }
};

module.exports = {
    getUserById,
    getPublicUserProfile,
    getPublicInfluencerProfile,
    getPublicBrandProfile,
    getPublicCrewProfile,
    searchUsers
};

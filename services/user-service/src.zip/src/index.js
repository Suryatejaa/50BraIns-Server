// src/index.js


require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { StatusCodes } = require('http-status-codes');
require('express-async-errors');
const logger = require('./utils/logger');
const { errorHandler } = require('./middleware/error-handler');
const { startUserSyncConsumer } = require('./sync/userSync.consumer');
const searchRoutes = require('./routes/search.routes');
const publicRoutes = require('./routes/public.routes');
const analyticsRoutes = require('./routes/analytics.routes');
const syncRoutes = require('./routes/sync.routes');
const app = express();
const PORT = process.env.PORT || 4002;
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } }));
app.get('/health', (req, res) => {
    res.status(StatusCodes.OK).json({
        status: 'ok',
        service: 'user-service',
        timestamp: new Date().toISOString(),
        purpose: 'High-performance user discovery and analytics - collaborates with auth-service'
    });
});
// app.use('/admin', adminRoutes);              // Admin routes for user management
app.use('/search', searchRoutes);          // High-performance search
app.use('/public', publicRoutes);          // Public profile views with caching
app.use('/analytics', analyticsRoutes);    // User analytics and insights
app.use('/sync', syncRoutes);
app.use((req, res) => {
    res.status(StatusCodes.NOT_FOUND).json({
        success: false,
        error: 'Not Found',
        message: `Route ${req.method} ${req.url} not found`,
        note: 'For user profile management, use auth-service at /api/auth/users'
    });
});
app.use(errorHandler);
const server = app.listen(PORT, () => {
    console.log(`✅ User Service running on port ${PORT}`);
    logger.info(`User Service running on port ${PORT}`);
    // Start RabbitMQ consumer for user registration sync
    console.log('36. About to start RabbitMQ consumer...');
    startUserSyncConsumer();
    console.log('37. RabbitMQ consumer started');
});

// Handle uncaught exceptions and rejections
process.on('uncaughtException', (error) => {
    logger.error('Uncaught Exception:', error);
    process.exit(1);
});

process.on('unhandledRejection', (error) => {
    logger.error('Unhandled Rejection:', error);
    server.close(() => process.exit(1));
});

module.exports = app;
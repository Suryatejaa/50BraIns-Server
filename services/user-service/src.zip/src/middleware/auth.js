// src/middleware/auth.js
const jwt = require('jsonwebtoken');
const { StatusCodes } = require('http-status-codes');
const logger = require('../utils/logger');
const { UnauthorizedError, ForbiddenError } = require('./error-handler');

/**
 * Authentication middleware
 */
const authenticate = async (req, res, next) => {
    try {
        // Get token from Authorization header
        const authHeader = req.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            throw new UnauthorizedError('Authentication required');
        }

        const token = authHeader.split(' ')[1];
        if (!token) {
            throw new UnauthorizedError('Authentication token missing');
        }

        try {
            // Verify token
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            req.user = {
                id: decoded.userId,
                roles: decoded.roles,
            };
            next();
        } catch (error) {
            if (error.name === 'TokenExpiredError') {
                throw new UnauthorizedError('Authentication token expired');
            }
            throw new UnauthorizedError('Invalid authentication token');
        }
    } catch (error) {
        next(error);
    }
};

/**
 * roles-based authorization middleware
 * @param {string[]} roles - Allowed roles
 */
const authorize = (...allowedroles) => {
    return (req, res, next) => {
        if (!req.user || !Array.isArray(req.user.roles)) {
            return res.status(403).json({ success: false, error: 'Forbidden: No roles assigned' });
        }
        // Check if user has at least one allowed roles
        const hasroles = req.user.roles.some(roles => allowedroles.includes(roles));
        if (!hasroles) {
            return res.status(403).json({ success: false, error: 'Forbidden: Insufficient roles' });
        }
        next();
    };
};

// Admin middleware (shorthand for admin/moderator roles)
const adminOnly = authorize('ADMIN', 'MODERATOR');

// Super admin middleware (admin only)
const superAdminOnly = authorize('ADMIN');

// Self or admin middleware (users can access their own data, admins can access any)
const selfOrAdmin = (paramName = 'userId') => {
    return (req, res, next) => {
        if (
            req.user.id === req.params[paramName] ||
            (Array.isArray(req.user.roles) && req.user.roles.includes('ADMIN'))
        ) {
            return next();
        }
        return res.status(403).json({ success: false, error: 'Forbidden: Not self or admin' });
    };
};

module.exports = {
    authenticate,
    authorize,
    adminOnly,
    superAdminOnly,
    selfOrAdmin,
};

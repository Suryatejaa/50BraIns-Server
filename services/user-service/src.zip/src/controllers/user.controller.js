// src/controllers/user.controller.js
const { StatusCodes } = require('http-status-codes');
const userService = require('../services/user.service');
const { BadRequestError, NotFoundError } = require('../middleware/error-handler');
const logger = require('../utils/logger');

/**
 * Get current user profile
 */
const getCurrentUser = async (req, res) => {
    const userId = req.user.id;
    logger.info(`Getting profile for user: ${userId}`);

    const user = await userService.getUserById(userId);
    if (!user) {
        throw new NotFoundError('User not found');
    }

    res.status(StatusCodes.OK).json({
        success: true,
        data: {
            user
        }
    });
};

/**
 * Update user profile
 */
const updateUserProfile = async (req, res) => {
    const userId = req.user.id;
    const updateData = req.body;

    logger.info(`Updating profile for user: ${userId}`);

    // Prevent updating sensitive fields
    delete updateData.password;
    delete updateData.email;
    delete updateData.roles;
    delete updateData.status;
    delete updateData.isActive;

    const updatedUser = await userService.updateUser(userId, updateData);

    res.status(StatusCodes.OK).json({
        success: true,
        message: 'Profile updated successfully',
        data: {
            user: updatedUser
        }
    });
};

/**
 * Update user profile picture
 */
const updateProfilePicture = async (req, res) => {
    const userId = req.user.id;
    const { profilePicture } = req.body;

    if (!profilePicture) {
        throw new BadRequestError('Profile picture URL is required');
    }

    logger.info(`Updating profile picture for user: ${userId}`);

    const updatedUser = await userService.updateUser(userId, { profilePicture });

    res.status(StatusCodes.OK).json({
        success: true,
        message: 'Profile picture updated successfully',
        data: {
            profilePicture: updatedUser.profilePicture
        }
    });
};

/**
 * Update social media handles
 */
const updateSocialHandles = async (req, res) => {
    const userId = req.user.id;
    const { instagramHandle, twitterHandle, linkedinHandle, youtubeHandle } = req.body;

    logger.info(`Updating social handles for user: ${userId}`);

    const updatedUser = await userService.updateUser(userId, {
        instagramHandle,
        twitterHandle,
        linkedinHandle,
        youtubeHandle
    });

    res.status(StatusCodes.OK).json({
        success: true,
        message: 'Social media handles updated successfully',
        data: {
            instagramHandle: updatedUser.instagramHandle,
            twitterHandle: updatedUser.twitterHandle,
            linkedinHandle: updatedUser.linkedinHandle,
            youtubeHandle: updatedUser.youtubeHandle
        }
    });
};

/**
 * Update roles-specific information
 */
const updaterolesInfo = async (req, res) => {
    const userId = req.user.id;
    const user = await userService.getUserById(userId);

    if (!user) {
        throw new NotFoundError('User not found');
    }

    const { roles } = user;
    const updateData = req.body;

    logger.info(`Updating ${roles}-specific info for user: ${userId}`);

    // Apply validations based on roles
    const updatedUser = await userService.updaterolespecificInfo(userId, roles, updateData);

    res.status(StatusCodes.OK).json({
        success: true,
        message: `${roles} information updated successfully`,
        data: {
            user: updatedUser
        }
    });
};

/**
 * Get user settings
 */
const getUserSettings = async (req, res) => {
    const userId = req.user.id;
    logger.info(`Getting settings for user: ${userId}`);

    const settings = await userService.getUserSettings(userId);

    res.status(StatusCodes.OK).json({
        success: true,
        data: {
            settings
        }
    });
};

/**
 * Update user settings
 */
const updateUserSettings = async (req, res) => {
    const userId = req.user.id;
    const settingsData = req.body;

    logger.info(`Updating settings for user: ${userId}`);

    const updatedSettings = await userService.updateUserSettings(userId, settingsData);

    res.status(StatusCodes.OK).json({
        success: true,
        message: 'Settings updated successfully',
        data: {
            settings: updatedSettings
        }
    });
};

module.exports = {
    getCurrentUser,
    updateUserProfile,
    updateProfilePicture,
    updateSocialHandles,
    updaterolesInfo,
    getUserSettings,
    updateUserSettings
};

// src/controllers/search.controller.js
const { StatusCodes } = require('http-status-codes');
const searchService = require('../services/search.service');
const logger = require('../utils/logger');

/**
 * Search users
 */
const searchUsers = async (req, res) => {
    const { query, roles, location, page = 1, limit = 10 } = req.query;

    logger.info('Searching users', { query, roles, location, page, limit });

    const results = await searchService.searchUsers({
        query,
        roles,
        location,
        page: parseInt(page),
        limit: parseInt(limit)
    });

    res.status(StatusCodes.OK).json({
        success: true,
        data: {
            results: results.users,
            pagination: {
                total: results.total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(results.total / parseInt(limit))
            }
        }
    });
};

/**
 * Search influencers
 */
const searchInfluencers = async (req, res) => {
    const {
        query,
        primaryNiche,
        primaryPlatform,
        contentCategories,
        location,
        followersMin,
        followersMax,
        page = 1,
        limit = 10
    } = req.query;

    logger.info('Searching influencers', {
        query, primaryNiche, primaryPlatform, contentCategories, location, followersMin, followersMax, page, limit
    });

    const results = await searchService.searchInfluencers({
        query,
        primaryNiche,
        primaryPlatform,
        contentCategories: contentCategories ? contentCategories.split(',') : undefined,
        location,
        followersMin: followersMin ? parseInt(followersMin) : undefined,
        followersMax: followersMax ? parseInt(followersMax) : undefined,
        page: parseInt(page),
        limit: parseInt(limit)
    });

    res.status(StatusCodes.OK).json({
        success: true,
        data: {
            results: results.influencers,
            pagination: {
                total: results.total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(results.total / parseInt(limit))
            }
        }
    });
};

/**
 * Search brands
 */
const searchBrands = async (req, res) => {
    const {
        query,
        industry,
        companyType,
        location,
        page = 1,
        limit = 10
    } = req.query;

    logger.info('Searching brands', {
        query, industry, companyType, location, page, limit
    });

    const results = await searchService.searchBrands({
        query,
        industry,
        companyType,
        location,
        page: parseInt(page),
        limit: parseInt(limit)
    });

    res.status(StatusCodes.OK).json({
        success: true,
        data: {
            results: results.brands,
            pagination: {
                total: results.total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(results.total / parseInt(limit))
            }
        }
    });
};

/**
 * Search crew members
 */
const searchCrew = async (req, res) => {
    const {
        query,
        experienceLevel,
        availability,
        workStyle,
        skills,
        location,
        hourlyRateMin,
        hourlyRateMax,
        page = 1,
        limit = 10
    } = req.query;

    logger.info('Searching crew members', {
        query, experienceLevel, availability, workStyle, skills, location, hourlyRateMin, hourlyRateMax, page, limit
    });

    const results = await searchService.searchCrew({
        query,
        experienceLevel,
        availability,
        workStyle,
        skills: skills ? skills.split(',') : undefined,
        location,
        hourlyRateMin: hourlyRateMin ? parseInt(hourlyRateMin) : undefined,
        hourlyRateMax: hourlyRateMax ? parseInt(hourlyRateMax) : undefined,
        page: parseInt(page),
        limit: parseInt(limit)
    });

    res.status(StatusCodes.OK).json({
        success: true,
        data: {
            results: results.crew,
            pagination: {
                total: results.total,
                page: parseInt(page),
                limit: parseInt(limit),
                pages: Math.ceil(results.total / parseInt(limit))
            }
        }
    });
};

module.exports = {
    searchUsers,
    searchInfluencers,
    searchBrands,
    searchCrew
};

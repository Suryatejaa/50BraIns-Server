const { consumeQueue } = require('../utils/rabbitmq');
const { prisma } = require('../config/database');
const logger = require('../utils/logger');

// Handler for user.registered event
async function handleUserRegistered(data) {
    try {
        // Upsert user profile (create if not exists, update if exists)
        await prisma.user.upsert({
            where: { id: data.id },
            update: {
                email: data.email,
                username: data.username,
                roles: data.roles,
                isActive: data.isActive,
                status: data.status,
                emailVerified: data.emailVerified,
                createdAt: data.createdAt
            },
            create: {
                id: data.id,
                email: data.email,
                username: data.username,
                roles: data.roles,
                isActive: data.isActive,
                status: data.status,
                emailVerified: data.emailVerified,
                createdAt: data.createdAt
            }
        });
        logger.info('User profile synced from auth-service', { userId: data.id });
    } catch (err) {
        logger.error('Failed to sync user profile from auth-service', err);
    }
}

function startUserSyncConsumer() {
    consumeQueue('user.registered', handleUserRegistered);
}

module.exports = { startUserSyncConsumer };

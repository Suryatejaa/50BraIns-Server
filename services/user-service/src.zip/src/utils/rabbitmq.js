const amqp = require('amqplib');
const logger = require('../utils/logger');

let channel = null;

async function connectRabbitMQ() {
    if (channel) return channel;
    const connection = await amqp.connect(process.env.RABBITMQ_URL || 'amqp://localhost');
    channel = await connection.createChannel();
    return channel;
}

async function publishToQueue(queue, message) {
    const ch = await connectRabbitMQ();
    await ch.assertQueue(queue, { durable: true });
    ch.sendToQueue(queue, Buffer.from(JSON.stringify(message)), { persistent: true });
    logger.info(`Published message to queue: ${queue}`);
}

async function consumeQueue(queue, onMessage) {
    const ch = await connectRabbitMQ();
    await ch.assertQueue(queue, { durable: true });
    ch.consume(queue, async (msg) => {
        if (msg !== null) {
            try {
                const content = JSON.parse(msg.content.toString());
                await onMessage(content);
                ch.ack(msg);
            } catch (err) {
                logger.error('Error processing message from queue', err);
                ch.nack(msg, false, false); // discard message
            }
        }
    });
    logger.info(`Consuming queue: ${queue}`);
}

module.exports = { publishToQueue, consumeQueue };

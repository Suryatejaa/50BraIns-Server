console.log('admin.routes.js: starting');
const express = require('express');
console.log('admin.routes.js: express loaded');
const { adminOnly, superAdminOnly } = require('../middleware/auth');
console.log('admin.routes.js: auth middleware loaded');
const adminController = require('../controllers/admin.controller');
console.log('admin.routes.js: admin.controller loaded');
const router = express.Router();
console.log('admin.routes.js: router created');

// User management routes
router.get('/users', adminController.getUsers);
router.get('/users/:userId', adminController.getUserById);
router.patch('/users/:userId/roles', superAdminOnly, adminController.updateUserRoles);
router.patch('/users/:userId/status', adminController.updateUserStatus);
router.post('/users/:userId/ban', adminController.banUser);
router.post('/users/:userId/unban', adminController.unbanUser);

// Delete user (Super Admin only)
router.delete('/users/:userId', superAdminOnly, adminController.deleteUser);

// System monitoring and logs
router.get('/stats', adminController.getStats);
router.get('/logs', adminController.getActivityLogs);
router.get('/health', adminController.getHealth);

// Dashboard routes
router.get('/dashboard/overview', adminController.getDashboardOverview);
router.get('/dashboard/recent-users', adminController.getRecentUsers);
router.get('/dashboard/active-sessions', adminController.getActiveSessions);

console.log('admin.routes.js: exporting router');
module.exports = router;

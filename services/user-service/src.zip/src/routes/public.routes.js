// src/routes/public.routes.js
const express = require('express');
const publicController = require('../controllers/public.controller');

const router = express.Router();

// Public profile routes (no authentication required)
router.get('/users/:userId', publicController.getPublicUserProfile);
router.get('/influencers/:userId', publicController.getPublicInfluencerProfile);
router.get('/brands/:userId', publicController.getPublicBrandProfile);
router.get('/crew/:userId', publicController.getPublicCrewProfile);

module.exports = router;

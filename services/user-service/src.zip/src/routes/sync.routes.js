// src/routes/sync.routes.js
const express = require('express');
const router = express.Router();
const syncController = require('../controllers/sync.controller');
const { authenticate, authorize } = require('../middleware/auth');

// Endpoints for synchronizing data between auth-service and user-service
// These should be called by auth-service when user data changes

// Webhook endpoint for auth-service to notify user-service of changes
router.post('/user-updated', syncController.handleUserUpdate);
router.post('/user-created', syncController.handleUserCreate);
router.post('/user-deleted', syncController.handleUserDelete);

// Manual sync endpoints (admin only)
router.post('/sync-all-users', authenticate, authorize(['ADMIN', 'SUPER_ADMIN']), syncController.syncAllUsers);
router.post('/sync-user/:userId', authenticate, authorize(['ADMIN', 'SUPER_ADMIN']), syncController.syncSingleUser);

// Health check for sync status
router.get('/sync-status', authenticate, authorize(['ADMIN', 'SUPER_ADMIN']), syncController.getSyncStatus);

module.exports = router;

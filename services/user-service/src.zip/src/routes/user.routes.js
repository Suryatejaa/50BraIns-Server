// src/routes/user.routes.js
const express = require('express');
const { authenticate } = require('../middleware/auth');
const userController = require('../controllers/user.controller');

const router = express.Router();

// Apply authentication to all routes

// User routes
router.get('/profile', userController.getCurrentUser);
router.put('/profile', userController.updateUserProfile);
router.put('/profile-picture', userController.updateProfilePicture);
router.put('/social', userController.updateSocialHandles);
router.put('/roles-info', userController.updaterolesInfo);
router.get('/settings', userController.getUserSettings);
router.put('/settings', userController.updateUserSettings);

module.exports = router;

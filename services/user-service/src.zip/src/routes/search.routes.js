// src/routes/search.routes.js
const express = require('express');
const { authenticate } = require('../middleware/auth');
const searchController = require('../controllers/search.controller');

const router = express.Router();


// Apply authentication to all routes

// Search routes
router.get('/users', searchController.searchUsers);
router.get('/influencers', searchController.searchInfluencers);
router.get('/brands', searchController.searchBrands);
router.get('/crew', searchController.searchCrew);

module.exports = router;
